# GamePlus
Gameplus is a simple way to make text based games in Python.

## Installation
`pip install gameplus`
## Usage
Import the library in your code using: 
```python
import gameplus
```